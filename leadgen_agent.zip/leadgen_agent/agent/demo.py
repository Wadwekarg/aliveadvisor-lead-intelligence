"""Sample candidates for --demo (fictional companies; no network or API keys needed)."""
from .models import Lead


def demo_leads() -> list[Lead]:
    return [
        Lead(company="Northwind Foods", domain="northwindfoods.example", lead_type_hint="expansion", source="news",
             signal="Northwind Foods raises $4M to expand its organic snack line into Southeast Asia.",
             country="US", contact_name="Dana Whitfield", contact_title="Founder & CEO",
             email="dana@northwindfoods.example", email_source="hunter (92% conf.)"),
        Lead(company="Lumen Robotics", domain="lumenrobotics.example", lead_type_hint="expansion", source="google",
             signal="Lumen Robotics is looking for international distributors for its warehouse robots.",
             country="US", contact_name="Marco Reyes", contact_title="Head of International",
             email="marco@lumenrobotics.example", email_source="hunter (88% conf.)"),
        Lead(company="Greenleaf Apparel", domain="greenleafapparel.example", lead_type_hint="expansion", source="google",
             signal="Greenleaf Apparel brand seeking licensing partners for its trademarked designs abroad.",
             country="US", email="info@greenleafapparel.example", email_source="website"),
        Lead(company="Brightside Dental Group", domain="brightsidedental.example", lead_type_hint="it_services", source="google",
             signal="Dental group published an RFP for a website redesign and mobile booking app.",
             country="US", email="office@brightsidedental.example", email_source="website"),
        Lead(company="Pacific Trade Consulting", domain="pacifictrade.example", lead_type_hint="partner", source="google",
             signal="Independent export consultant helping small businesses reach overseas markets.",
             country="US", contact_name="Priya Nair", contact_title="Principal Consultant",
             email="priya@pacifictrade.example", email_source="csv"),
        Lead(company="Old Town Hardware", domain="oldtownhardware.example", lead_type_hint="it_services", source="google",
             signal="Local hardware store; website last updated years ago.", country="US"),
    ]
