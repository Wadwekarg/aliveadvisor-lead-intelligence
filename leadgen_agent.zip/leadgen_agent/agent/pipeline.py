"""discover -> dedupe -> resolve -> enrich -> score -> draft -> spreadsheet"""
from . import sheet
from .config import env
from .demo import demo_leads
from .enrich import enrich
from .llm import ClaudeLLM, DemoLLM
from .models import Lead
from .sources import discover_from_search, domain_of, import_csv, resolve_company_site

ALL_TYPES = ["expansion", "it_services", "partner"]


def _dedupe(leads: list[Lead], seen: set[str]) -> list[Lead]:
    out = []
    for l in leads:
        if l.domain:
            if l.domain in seen:
                continue
            seen.add(l.domain)
        out.append(l)
    return out


def run_discovery(cfg: dict, out_path: str, types: list[str] | None, limit: int,
                  csv_path: str | None, demo: bool) -> None:
    types = types or ALL_TYPES
    hunter_key = env("HUNTER_API_KEY")
    seen = sheet.existing_domains(out_path)
    print(f"Spreadsheet already holds {len(seen)} companies (they will be skipped).")

    # ---- 1. Discover
    if demo:
        print("DEMO MODE: sample data, no API calls.")
        llm = DemoLLM(cfg)
        leads = demo_leads()
    else:
        key, serper = env("ANTHROPIC_API_KEY"), env("SERPER_API_KEY")
        if not key:
            raise SystemExit("Missing ANTHROPIC_API_KEY (put it in .env). Use --demo to try without keys.")
        llm = ClaudeLLM(cfg, key)
        leads = []
        if csv_path:
            print(f"Importing {csv_path} ...")
            leads += import_csv(csv_path, types[0])
        if serper:
            print("Searching Google ...")
            leads += discover_from_search(cfg, serper, types)
        elif not csv_path:
            raise SystemExit("Missing SERPER_API_KEY (put it in .env), or pass --csv.")
    print(f"Discovered {len(leads)} raw results.")

    # ---- 2. Resolve article hits (news) into the real company website
    if not demo:
        serper = env("SERPER_API_KEY")
        resolved = []
        for l in leads:
            if not l.needs_resolution:
                resolved.append(l)
                continue
            try:
                info = llm.extract_company(l)
            except Exception as e:
                print(f"  ! extract failed: {e}")
                continue
            if not info.get("is_company") or not info.get("company") or not serper:
                continue
            l.company = info["company"]
            l.domain, l.url = resolve_company_site(cfg, serper, l.company)
            if l.domain:
                l.needs_resolution = False
                resolved.append(l)
        leads = resolved

    leads = _dedupe(leads, seen)[:limit]
    print(f"{len(leads)} new companies to process (limit {limit}).")

    # ---- 3. Enrich
    for i, l in enumerate(leads, 1):
        print(f"[{i}/{len(leads)}] enrich  {l.company} ({l.domain or 'no domain'})")
        if not demo:
            enrich(l, cfg, hunter_key)

    # ---- 4. Score
    keep = []
    for i, l in enumerate(leads, 1):
        try:
            r = llm.score(l)
        except Exception as e:
            print(f"  ! scoring failed for {l.company}: {e}")
            continue
        l.is_target = bool(r.get("is_target_company", True))
        l.score = max(0, min(100, int(r.get("score", 0))))
        l.lead_type = r.get("lead_type") or l.lead_type_hint
        l.recommended_service = r.get("recommended_service", "")
        l.reasoning = r.get("reasoning", "")
        l.hook = r.get("personalization_hook", "")
        ok = l.is_target and l.score >= cfg["scoring"]["min_score_to_list"] and l.lead_type != "none"
        print(f"[{i}/{len(leads)}] score   {l.company}: {l.score}{'' if ok else '  (dropped)'}")
        if ok:
            keep.append(l)

    # ---- 5. Draft
    footer = cfg.get("email_footer", "").strip()
    for i, l in enumerate(keep, 1):
        try:
            d = llm.draft(l)
        except Exception as e:
            print(f"  ! drafting failed for {l.company}: {e}")
            continue
        l.subject = d.get("subject", "")
        body = d.get("email_body", "").strip()
        l.email_body = f"{body}\n\n{footer}" if footer else body
        l.linkedin_note = d.get("linkedin_note", "")
        print(f"[{i}/{len(keep)}] drafted {l.company}")

    # ---- 6. Write
    n = sheet.append_leads(out_path, keep)
    print(f"\nDone. {n} leads added to {out_path}. Open it, review, set Status, then run 'export'.")
