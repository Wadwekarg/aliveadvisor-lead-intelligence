from dataclasses import dataclass, field


@dataclass
class Lead:
    # --- discovered ---
    company: str
    domain: str = ""
    url: str = ""
    lead_type_hint: str = ""          # expansion | it_services | partner
    source: str = ""                  # e.g. "google", "news", "csv"
    signal: str = ""                  # the snippet / headline that triggered discovery
    title: str = ""                   # raw search-result title
    needs_resolution: bool = False    # True when the result was an article, not the company site
    country: str = ""

    # --- contact ---
    contact_name: str = ""
    contact_title: str = ""
    email: str = ""
    email_source: str = ""            # hunter | website | csv
    linkedin_url: str = ""

    # --- enrichment ---
    site_title: str = ""
    site_description: str = ""
    site_text: str = ""
    site_signals: dict = field(default_factory=dict)

    # --- scoring ---
    is_target: bool = True
    score: int = 0
    lead_type: str = ""
    recommended_service: str = ""
    reasoning: str = ""
    hook: str = ""

    # --- draft ---
    subject: str = ""
    email_body: str = ""
    linkedin_note: str = ""
