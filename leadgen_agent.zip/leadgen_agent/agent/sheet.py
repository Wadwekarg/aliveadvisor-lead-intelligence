"""Spreadsheet I/O. The workbook is the system of record: you approve/edit here, the agent reads it back."""
import csv
from collections import defaultdict
from datetime import date
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.formatting.rule import ColorScaleRule, FormulaRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from .models import Lead

COLUMNS = [  # (header, width)
    ("Status", 12), ("Score", 8), ("Lead Type", 13), ("Company", 24), ("Website", 26),
    ("Contact Name", 20), ("Contact Title", 22), ("Email", 28), ("Email Source", 16),
    ("LinkedIn", 28), ("Country", 10), ("Signal / Trigger", 42), ("Why It Fits", 46),
    ("Recommended Service", 24), ("Subject", 32), ("Email Draft", 70), ("LinkedIn Note", 44),
    ("Source", 10), ("Date Added", 12), ("Outcome", 16), ("Notes", 28), ("Domain", 20),
]
H = {name: i + 1 for i, (name, _) in enumerate(COLUMNS)}
STATUS_OPTIONS = "Pending,Approved,Needs Edit,Rejected"
OUTCOME_OPTIONS = "Exported,Sent,Replied,Meeting Booked,Won,Not Interested,Bounced"
MAX_ROWS = 5000
FONT = "Arial"


def _create(path: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Leads"
    hdr_fill = PatternFill("solid", fgColor="1F3864")
    for i, (name, width) in enumerate(COLUMNS, start=1):
        c = ws.cell(row=1, column=i, value=name)
        c.font = Font(name=FONT, bold=True, color="FFFFFF", size=10)
        c.fill = hdr_fill
        c.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[1].height = 30
    ws.freeze_panes = "E2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(COLUMNS))}{MAX_ROWS}"

    dv1 = DataValidation(type="list", formula1=f'"{STATUS_OPTIONS}"', allow_blank=True)
    dv2 = DataValidation(type="list", formula1=f'"{OUTCOME_OPTIONS}"', allow_blank=True)
    ws.add_data_validation(dv1)
    ws.add_data_validation(dv2)
    dv1.add(f"A2:A{MAX_ROWS}")
    dv2.add(f"{get_column_letter(H['Outcome'])}2:{get_column_letter(H['Outcome'])}{MAX_ROWS}")

    sc = get_column_letter(H["Score"])
    ws.conditional_formatting.add(f"{sc}2:{sc}{MAX_ROWS}", ColorScaleRule(
        start_type="num", start_value=30, start_color="F8696B",
        mid_type="num", mid_value=60, mid_color="FFEB84",
        end_type="num", end_value=90, end_color="63BE7B"))
    last = get_column_letter(len(COLUMNS))
    ws.conditional_formatting.add(f"A2:{last}{MAX_ROWS}", FormulaRule(
        formula=['$A2="Approved"'], fill=PatternFill("solid", bgColor="E2EFDA")))
    ws.conditional_formatting.add(f"A2:{last}{MAX_ROWS}", FormulaRule(
        formula=['$A2="Rejected"'], font=Font(name=FONT, color="999999"),
        fill=PatternFill("solid", bgColor="EDEDED")))

    g = wb.create_sheet("How to use")
    rows = [
        ("HOW TO USE THIS SHEET", ""),
        ("", ""),
        ("1. Review", "Open the Leads tab. Highest scores first (sort/filter on Score). Read 'Why It Fits' and the draft."),
        ("2. Edit", "Edit Subject / Email Draft / LinkedIn Note directly in the cell. Fix or add Contact Name and Email if missing."),
        ("3. Decide", "Set Status (column A): Approved, Needs Edit, or Rejected. Rejected leads teach you what to change in config.yaml."),
        ("4. Send", "Run: python run.py export  -> writes approved rows to a CSV for your sending tool (or send manually)."),
        ("5. Track", "Update Outcome (Sent, Replied, Meeting Booked, Won, Not Interested, Bounced) as things happen."),
        ("6. Tune", "Run: python run.py stats  -> shows which score bands and lead types actually reply. Adjust config.yaml."),
        ("", ""),
        ("Cells you edit", "Status, Outcome, Notes, and any draft/contact cell. Everything else is written by the agent."),
        ("Domain column", "Used to avoid duplicates on later runs. Do not delete it."),
        ("Email Source", "'hunter' = looked up by Hunter.io; 'website' = found on the company site (often generic like info@); 'csv' = from your import."),
        ("Generic emails", "info@/contact@ addresses rarely reach a decision maker. Prefer rows with a named contact."),
    ]
    for r, (a, b) in enumerate(rows, start=1):
        g.cell(row=r, column=1, value=a).font = Font(name=FONT, bold=True, size=12 if r == 1 else 10)
        g.cell(row=r, column=2, value=b).font = Font(name=FONT, size=10)
        g.cell(row=r, column=2).alignment = Alignment(wrap_text=True, vertical="top")
    g.column_dimensions["A"].width = 18
    g.column_dimensions["B"].width = 110
    wb.save(path)


def _open(path: Path):
    if not path.exists():
        _create(path)
    wb = load_workbook(path)
    return wb, wb["Leads"]


def existing_domains(path: str) -> set[str]:
    p = Path(path)
    if not p.exists():
        return set()
    _, ws = _open(p)
    col = H["Domain"]
    return {str(ws.cell(row=r, column=col).value).lower()
            for r in range(2, ws.max_row + 1) if ws.cell(row=r, column=col).value}


def append_leads(path: str, leads: list[Lead]) -> int:
    p = Path(path)
    wb, ws = _open(p)
    start = 2
    while ws.cell(row=start, column=1).value is not None:
        start += 1
    today = date.today().isoformat()
    body_font = Font(name=FONT, size=10)
    wrap = Alignment(wrap_text=True, vertical="top")
    for i, l in enumerate(sorted(leads, key=lambda x: -x.score)):
        r = start + i
        values = {
            "Status": "Pending", "Score": l.score, "Lead Type": l.lead_type, "Company": l.company,
            "Website": f"https://{l.domain}" if l.domain else "", "Contact Name": l.contact_name,
            "Contact Title": l.contact_title, "Email": l.email, "Email Source": l.email_source,
            "LinkedIn": l.linkedin_url, "Country": l.country, "Signal / Trigger": l.signal,
            "Why It Fits": l.reasoning, "Recommended Service": l.recommended_service,
            "Subject": l.subject, "Email Draft": l.email_body, "LinkedIn Note": l.linkedin_note,
            "Source": l.source, "Date Added": today, "Outcome": "", "Notes": "", "Domain": l.domain,
        }
        for name, val in values.items():
            c = ws.cell(row=r, column=H[name], value=val)
            c.font = body_font
            c.alignment = wrap
        site = ws.cell(row=r, column=H["Website"])
        if l.domain:
            site.hyperlink = f"https://{l.domain}"
            site.font = Font(name=FONT, size=10, color="0563C1", underline="single")
        ws.cell(row=r, column=H["Score"]).alignment = Alignment(horizontal="center", vertical="top")
        ws.row_dimensions[r].height = 150
    wb.save(p)
    return len(leads)


def read_rows(path: str) -> list[dict]:
    wb, ws = _open(Path(path))
    rows = []
    for r in range(2, ws.max_row + 1):
        if ws.cell(row=r, column=1).value is None:
            continue
        d = {name: ws.cell(row=r, column=i).value for name, i in H.items()}
        d["_row"] = r
        rows.append(d)
    return rows


# ------------------------------------------------------------------ stats / export
def stats(path: str) -> str:
    rows = read_rows(path)
    if not rows:
        return "No leads in the sheet yet."
    replied = {"Replied", "Meeting Booked", "Won"}
    sent = {"Exported", "Sent", "Replied", "Meeting Booked", "Won", "Not Interested", "Bounced"}

    def band(s):
        s = s or 0
        return "80-100" if s >= 80 else "60-79" if s >= 60 else "40-59" if s >= 40 else "<40"

    def table(title, key):
        g = defaultdict(lambda: defaultdict(int))
        for d in rows:
            k = key(d)
            g[k]["leads"] += 1
            g[k]["approved"] += d["Status"] in ("Approved", "Needs Edit")
            g[k]["rejected"] += d["Status"] == "Rejected"
            g[k]["sent"] += d["Outcome"] in sent
            g[k]["replied"] += d["Outcome"] in replied
            g[k]["meetings"] += d["Outcome"] in ("Meeting Booked", "Won")
        out = [f"\n{title}", f"{'':14}{'leads':>7}{'approve%':>10}{'sent':>6}{'reply%':>8}{'meetings':>10}"]
        for k in sorted(g, reverse=True):
            v = g[k]
            decided = v["approved"] + v["rejected"]
            ap = f"{100 * v['approved'] / decided:.0f}%" if decided else "-"
            rp = f"{100 * v['replied'] / v['sent']:.0f}%" if v["sent"] else "-"
            out.append(f"{str(k):14}{v['leads']:>7}{ap:>10}{v['sent']:>6}{rp:>8}{v['meetings']:>10}")
        return "\n".join(out)

    return (f"Total leads: {len(rows)}"
            + table("By score band", lambda d: band(d["Score"]))
            + table("By lead type", lambda d: d["Lead Type"] or "?")
            + table("By source", lambda d: d["Source"] or "?")
            + "\n\nTip: if high-score bands don't reply more than low ones, change the rubric weights in config.yaml.")


def export_approved(path: str, out_csv: str, mark: bool = True) -> tuple[int, int]:
    p = Path(path)
    wb, ws = _open(p)
    rows = [d for d in read_rows(path) if d["Status"] in ("Approved",) and not d["Outcome"]]
    ready = [d for d in rows if d["Email"] and d["Email Draft"]]
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["email", "first_name", "last_name", "company", "subject", "body",
                    "linkedin_url", "linkedin_note", "lead_type", "website"])
        for d in ready:
            name = (d["Contact Name"] or "").split()
            w.writerow([d["Email"], name[0] if name else "", " ".join(name[1:]), d["Company"],
                        d["Subject"], d["Email Draft"], d["LinkedIn"] or "", d["LinkedIn Note"],
                        d["Lead Type"], d["Website"]])
            if mark:
                ws.cell(row=d["_row"], column=H["Outcome"], value="Exported")
    if mark and ready:
        wb.save(p)
    return len(ready), len(rows) - len(ready)
