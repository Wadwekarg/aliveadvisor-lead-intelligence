"""Discovery: Google search + news (via Serper.dev) and CSV import (LinkedIn/Apollo exports)."""
import csv
import re
import time
from urllib.parse import urlparse

import requests

from .models import Lead

MULTI_TLDS = {"co.uk", "com.au", "com.sg", "co.in", "co.nz", "com.my", "co.za",
              "com.br", "com.hk", "co.jp", "com.ph", "co.id", "com.mx", "ae"}


def domain_of(url: str) -> str:
    """Return the registrable-ish domain of a URL or bare domain."""
    if not url:
        return ""
    host = urlparse(url if "//" in url else "//" + url).netloc.lower()
    host = host.split("@")[-1].split(":")[0]
    if host.startswith("www."):
        host = host[4:]
    parts = host.split(".")
    if len(parts) >= 3 and ".".join(parts[-2:]) in MULTI_TLDS:
        return ".".join(parts[-3:])
    if len(parts) >= 2:
        return ".".join(parts[-2:])
    return host


def _matches(domain: str, domains: list[str]) -> bool:
    return any(domain == d or domain.endswith("." + d) for d in domains)


def _clean_title(title: str) -> str:
    return re.split(r"\s[\|\-–—:·]\s", title)[0].strip()[:80]


def _serper(endpoint: str, body: dict, key: str) -> dict:
    r = requests.post(
        f"https://google.serper.dev/{endpoint}",
        headers={"X-API-KEY": key, "Content-Type": "application/json"},
        json=body, timeout=20,
    )
    r.raise_for_status()
    return r.json()


def discover_from_search(cfg: dict, serper_key: str, types: list[str]) -> list[Lead]:
    s = cfg["search"]
    excluded = cfg.get("exclude_domains", [])
    articles = cfg.get("article_domains", [])
    leads: list[Lead] = []

    jobs = []
    for t in types:
        for q in s.get("queries", {}).get(t, []):
            jobs.append(("search", t, q))
        for q in s.get("news_queries", {}).get(t, []):
            jobs.append(("news", t, q))

    for kind, lead_type, q in jobs:
        body = {"q": q, "num": s.get("results_per_query", 10), "gl": s.get("gl", "us")}
        if kind == "news":
            body["tbs"] = s.get("news_window", "qdr:m")
        try:
            data = _serper(kind, body, serper_key)
        except Exception as e:  # keep going if one query fails
            print(f"  ! search failed for {q!r}: {e}")
            continue
        items = data.get("news" if kind == "news" else "organic", [])
        print(f"  {kind:6} {lead_type:12} {len(items):2} results  <- {q}")
        for it in items:
            url = it.get("link", "")
            dom = domain_of(url)
            if not dom or _matches(dom, excluded):
                continue
            is_article = kind == "news" or _matches(dom, articles)
            title = it.get("title", "")
            leads.append(Lead(
                company=_clean_title(title) or dom,
                domain="" if is_article else dom,
                url="" if is_article else url,
                lead_type_hint=lead_type,
                source="news" if kind == "news" else "google",
                signal=(f"{title}. {it.get('snippet', '')}").strip()[:500],
                title=title,
                needs_resolution=is_article,
                country=s.get("gl", "").upper(),
            ))
        time.sleep(0.3)
    return leads


def resolve_company_site(cfg: dict, serper_key: str, company: str) -> tuple[str, str]:
    """Find a company's own website via search. Returns (domain, url) or ('','')."""
    excluded = cfg.get("exclude_domains", []) + cfg.get("article_domains", [])
    try:
        data = _serper("search", {"q": f'"{company}" official website', "num": 5,
                                  "gl": cfg["search"].get("gl", "us")}, serper_key)
    except Exception:
        return "", ""
    for it in data.get("organic", []):
        dom = domain_of(it.get("link", ""))
        if dom and not _matches(dom, excluded):
            return dom, it["link"]
    return "", ""


# ---------------------------------------------------------------- CSV import
ALIASES = {
    "company": ["company", "company name", "organization", "account name", "account"],
    "website": ["website", "company website", "domain", "url", "company domain"],
    "first": ["first name", "first_name", "firstname"],
    "last": ["last name", "last_name", "lastname"],
    "name": ["name", "full name", "contact name"],
    "title": ["title", "job title", "position"],
    "email": ["email", "email address", "work email"],
    "linkedin": ["linkedin", "linkedin url", "person linkedin url", "profile url", "linkedin profile"],
    "country": ["country", "location", "company country"],
    "notes": ["notes", "signal", "description", "headline"],
}


def _pick(row: dict, field: str) -> str:
    low = {k.strip().lower(): (v or "").strip() for k, v in row.items() if k}
    for alias in ALIASES[field]:
        if low.get(alias):
            return low[alias]
    return ""


def import_csv(path: str, lead_type: str = "expansion") -> list[Lead]:
    """Import leads from a CSV export (Sales Navigator tools, Apollo, Crunchbase, your own list)."""
    leads = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            site = _pick(row, "website")
            email = _pick(row, "email")
            dom = domain_of(site) or (domain_of(email.split("@")[1]) if "@" in email else "")
            company = _pick(row, "company") or dom
            if not company:
                continue
            name = _pick(row, "name") or f"{_pick(row, 'first')} {_pick(row, 'last')}".strip()
            leads.append(Lead(
                company=company, domain=dom,
                url=site if site.startswith("http") else (f"https://{dom}" if dom else ""),
                lead_type_hint=lead_type, source="csv",
                signal=_pick(row, "notes")[:500],
                country=_pick(row, "country"),
                contact_name=name, contact_title=_pick(row, "title"),
                email=email, email_source="csv" if email else "",
                linkedin_url=_pick(row, "linkedin"),
            ))
    return leads
