"""Claude-powered scoring, drafting and company extraction (plus a no-API demo stand-in)."""
import json
import re
import time

from .models import Lead


def parse_json(text: str) -> dict:
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError(f"No JSON object in model output: {text[:200]!r}")
    return json.loads(text[start:end + 1])


def _lead_facts(lead: Lead) -> str:
    return json.dumps({
        "company": lead.company,
        "website": lead.domain,
        "country": lead.country,
        "discovery_source": lead.source,
        "lead_type_hint": lead.lead_type_hint,
        "trigger_signal": lead.signal,
        "site_title": lead.site_title,
        "site_description": lead.site_description,
        "site_text_excerpt": lead.site_text[:1800],
        "site_signals": lead.site_signals,
        "contact_name": lead.contact_name,
        "contact_title": lead.contact_title,
        "email_found": bool(lead.email),
        "email_is_generic": bool(lead.email) and lead.email.split("@")[0] in
            ("info", "contact", "hello", "support", "sales", "admin", "office"),
    }, ensure_ascii=False, indent=1)


class ClaudeLLM:
    def __init__(self, cfg: dict, api_key: str):
        import anthropic  # imported lazily so --demo works without the package
        self.client = anthropic.Anthropic(api_key=api_key)
        self.cfg = cfg
        self.model = cfg["llm"]["model"]

    def _ask(self, system: str, user: str, max_tokens: int = 900) -> dict:
        last = None
        for attempt in range(3):
            try:
                msg = self.client.messages.create(
                    model=self.model, max_tokens=max_tokens, system=system,
                    messages=[{"role": "user", "content": user}],
                )
                return parse_json("".join(b.text for b in msg.content if getattr(b, "type", "") == "text"))
            except Exception as e:
                last = e
                time.sleep(1.5 * (attempt + 1))
        raise RuntimeError(f"LLM call failed: {last}")

    # ------------------------------------------------------------------
    def extract_company(self, lead: Lead) -> dict:
        system = ("You extract the single main company that a news headline/snippet is about. "
                  'Reply with JSON only: {"company": "<name or empty string>", "is_company": true|false}. '
                  "is_company is false if the item is a list, opinion piece, or about no specific company.")
        return self._ask(system, f"Title: {lead.title}\nSnippet: {lead.signal}", 200)

    def score(self, lead: Lead) -> dict:
        c = self.cfg
        system = f"""You qualify sales leads for {c['company']['name']}.

ABOUT THE BUSINESS:
{c['company']['offer']}

IDEAL CUSTOMER PROFILE:
{c['icp']['description']}

SCORING RUBRIC:
{c['scoring']['rubric']}

Rules: use ONLY the evidence provided. Never invent facts. If the page looks like a directory,
news site, blog, marketplace, or big-name competitor, set is_target_company=false.

Reply with JSON only, exactly this shape:
{{"is_target_company": true|false,
  "score": <0-100 integer>,
  "lead_type": "expansion"|"it_services"|"partner"|"none",
  "recommended_service": "<which one Aliveadvisor service fits best>",
  "reasoning": "<2 sentences max, cite the evidence>",
  "personalization_hook": "<one specific, true observation from the evidence usable in an opening line>"}}"""
        return self._ask(system, _lead_facts(lead))

    def draft(self, lead: Lead) -> dict:
        c = self.cfg["company"]
        system = f"""You write short, human cold outreach for {c['name']} ({c['website']}).
Sender: {c['sender_name']}, {c['sender_title']}.

ABOUT THE OFFER:
{c['offer']}

RULES
- Email body: 70-110 words, plain text, no markdown, no emojis, no hype or buzzwords.
- Open with ONE specific, true observation taken from the provided facts (the personalization hook).
  Never invent news, numbers, funding, or relationships. If facts are thin, keep the opener modest.
- Connect it to exactly one relevant service. One soft call to action: a short call. Booking link: {c['booking_link']}
- Greeting: use the contact's first name if known, else "Hi there,".
- If lead_type is "partner", invite them to become an Overseas Partner / US Representative instead of selling a service.
- End with the sender's name only (no footer; it is added automatically).
- Subject: under 8 words, specific, no clickbait, no ALL CAPS.
- LinkedIn note: under 280 characters, friendly, no pitch-slap, no link.

Reply with JSON only: {{"subject": "...", "email_body": "...", "linkedin_note": "..."}}"""
        user = _lead_facts(lead) + "\n\nSCORING RESULT:\n" + json.dumps({
            "lead_type": lead.lead_type, "recommended_service": lead.recommended_service,
            "reasoning": lead.reasoning, "personalization_hook": lead.hook}, ensure_ascii=False)
        return self._ask(system, user, 900)


class DemoLLM:
    """Offline stand-in so you can see the whole pipeline + spreadsheet without any API keys."""

    def __init__(self, cfg: dict):
        self.cfg = cfg

    def extract_company(self, lead: Lead) -> dict:
        return {"company": lead.company, "is_company": True}

    def score(self, lead: Lead) -> dict:
        text = (lead.signal + " " + lead.site_description).lower()
        pts = 34
        for kw in ("expan", "international", "global", "distributor", "partner", "licens", "funding", "raise"):
            if kw in text:
                pts += 9
        pts += 10 if lead.email else 0
        pts += 8 if lead.contact_name else 0
        pts = min(pts, 95)
        service = {"expansion": "Go Global Platform / Business Advisory",
                   "it_services": "Website Development & Digital Marketing",
                   "partner": "Overseas Partner / US Representative program"}.get(lead.lead_type_hint, "Business Advisory")
        return {"is_target_company": pts >= 30, "score": pts,
                "lead_type": lead.lead_type_hint or "expansion", "recommended_service": service,
                "reasoning": "[DEMO] Keyword-based score; real runs use Claude to judge the evidence.",
                "personalization_hook": (lead.signal or lead.company)[:120]}

    def draft(self, lead: Lead) -> dict:
        first = lead.contact_name.split()[0] if lead.contact_name else "there"
        c = self.cfg["company"]
        body = (f"Hi {first},\n\n[DEMO DRAFT] I came across {lead.company} - {lead.hook}\n\n"
                f"We help companies in a similar position with {lead.recommended_service.lower()}. "
                f"Would a short call be useful? You can pick a time here: {c['booking_link']}\n\n{c['sender_name']}")
        return {"subject": f"Quick idea for {lead.company}", "email_body": body,
                "linkedin_note": f"Hi {first}, I follow companies growing across borders and {lead.company} caught my eye. Would love to connect."}
