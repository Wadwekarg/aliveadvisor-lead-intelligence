"""Enrichment: read the company website, find contact emails, optionally ask Hunter for decision makers."""
import re
import time
from urllib import robotparser
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

from .models import Lead

UA = "Mozilla/5.0 (compatible; LeadResearchBot/1.0; +https://aliveadvisor.com)"
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
JUNK_EMAIL = ("sentry", "wixpress", "example.", "domain.com", "yourdomain", ".png", ".jpg", ".gif", ".webp", ".svg")
GENERIC_PREFIXES = ("info", "contact", "hello", "support", "sales", "admin", "office", "enquiries", "inquiries", "team")

_robots_cache: dict[str, robotparser.RobotFileParser | None] = {}


def _allowed(url: str, timeout: int) -> bool:
    p = urlparse(url)
    base = f"{p.scheme}://{p.netloc}"
    if base not in _robots_cache:
        rp = robotparser.RobotFileParser()
        try:
            r = requests.get(base + "/robots.txt", headers={"User-Agent": UA}, timeout=timeout)
            rp.parse(r.text.splitlines() if r.status_code == 200 else [])
            _robots_cache[base] = rp
        except Exception:
            _robots_cache[base] = None
    rp = _robots_cache[base]
    return True if rp is None else rp.can_fetch(UA, url)


def _get(url: str, cfg: dict) -> str | None:
    e = cfg["enrich"]
    t = e.get("timeout_seconds", 12)
    try:
        if e.get("respect_robots_txt", True) and not _allowed(url, t):
            return None
        r = requests.get(url, headers={"User-Agent": UA}, timeout=t, allow_redirects=True)
        if r.status_code != 200 or "text/html" not in r.headers.get("content-type", ""):
            return None
        return r.text
    except Exception:
        return None


def _emails_from(html: str, domain: str) -> list[str]:
    soup = BeautifulSoup(html, "html.parser")
    found = set(m.lower() for m in EMAIL_RE.findall(soup.get_text(" ")))
    for a in soup.select('a[href^="mailto:"]'):
        found.update(m.lower() for m in EMAIL_RE.findall(a["href"]))
    clean = [e for e in found if not any(j in e for j in JUNK_EMAIL)]
    # prefer emails on the company's own domain
    clean.sort(key=lambda e: (not e.endswith("@" + domain), e.split("@")[0] in GENERIC_PREFIXES, e))
    return clean[:5]


def enrich_website(lead: Lead, cfg: dict) -> None:
    if not lead.domain:
        return
    url = lead.url or f"https://{lead.domain}"
    html = _get(url, cfg)
    if not html:
        lead.site_signals["site_reachable"] = False
        return
    soup = BeautifulSoup(html, "html.parser")
    lead.site_title = (soup.title.string or "").strip()[:200] if soup.title and soup.title.string else ""
    meta = soup.find("meta", attrs={"name": "description"}) or soup.find("meta", attrs={"property": "og:description"})
    lead.site_description = (meta.get("content", "") if meta else "").strip()[:400]

    years = [int(y) for y in re.findall(r"(?:©|&copy;|copyright)[^0-9]{0,20}((?:19|20)\d\d)", html, flags=re.I)]
    lead.site_signals = {
        "site_reachable": True,
        "https": url.startswith("https"),
        "mobile_viewport_tag": bool(soup.find("meta", attrs={"name": "viewport"})),
        "latest_copyright_year": max(years) if years else None,
    }

    emails = _emails_from(html, lead.domain)
    for tag in soup(["script", "style", "noscript", "svg"]):
        tag.decompose()
    lead.site_text = re.sub(r"\s+", " ", soup.get_text(" "))[:2500]

    # one extra page: contact / about
    for a in soup.find_all("a", href=True):
        href = a["href"].lower()
        if any(k in href for k in ("contact", "about")) and not href.startswith(("mailto:", "tel:")):
            target = urljoin(url, a["href"])
            if domain_matches(target, lead.domain):
                page = _get(target, cfg)
                if page:
                    emails += _emails_from(page, lead.domain)
                break
    if not lead.email and emails:
        # keep the best own-domain email
        best = sorted(set(emails), key=lambda e: (not e.endswith("@" + lead.domain), e.split("@")[0] in GENERIC_PREFIXES))[0]
        lead.email, lead.email_source = best, "website"


def domain_matches(url: str, domain: str) -> bool:
    host = urlparse(url).netloc.lower().removeprefix("www.")
    return host == domain or host.endswith("." + domain)


def hunter_decision_maker(lead: Lead, key: str, cfg: dict) -> None:
    """Fill contact name/title/email from Hunter's domain search (needs HUNTER_API_KEY)."""
    if not lead.domain:
        return
    try:
        r = requests.get("https://api.hunter.io/v2/domain-search",
                         params={"domain": lead.domain, "limit": 10,
                                 "seniority": "senior,executive", "api_key": key}, timeout=20)
        r.raise_for_status()
        people = r.json().get("data", {}).get("emails", [])
    except Exception as e:
        print(f"  ! hunter failed for {lead.domain}: {e}")
        return
    titles = [t.lower() for t in cfg["enrich"].get("target_titles", [])]

    def rank(p):
        pos = (p.get("position") or "").lower()
        hit = max((len(titles) - i for i, t in enumerate(titles) if t in pos), default=0)
        return (hit, p.get("confidence", 0))

    people = [p for p in people if p.get("value") and p.get("first_name")]
    if not people:
        return
    best = max(people, key=rank)
    lead.contact_name = f"{best.get('first_name', '')} {best.get('last_name', '')}".strip()
    lead.contact_title = best.get("position") or ""
    lead.email = best["value"]
    lead.email_source = f"hunter ({best.get('confidence', '?')}% conf.)"
    lead.linkedin_url = best.get("linkedin") or lead.linkedin_url


def enrich(lead: Lead, cfg: dict, hunter_key: str = "") -> None:
    if cfg["enrich"].get("fetch_websites", True):
        enrich_website(lead, cfg)
    if hunter_key and not (lead.contact_name and lead.email):
        hunter_decision_maker(lead, hunter_key, cfg)
        time.sleep(0.3)
