#!/usr/bin/env python3
"""Lead-gen agent CLI.

  python run.py discover            # find, enrich, score, draft -> leads.xlsx
  python run.py discover --demo     # try it with sample data, no API keys
  python run.py discover --csv my_list.csv --types expansion
  python run.py stats               # which score bands / lead types actually convert
  python run.py export              # approved rows -> CSV for your sending tool
"""
import argparse

from agent import sheet
from agent.config import load_config
from agent.pipeline import ALL_TYPES, run_discovery


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=None, help="path to config.yaml")
    ap.add_argument("--sheet", default="leads.xlsx", help="spreadsheet path (default leads.xlsx)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    d = sub.add_parser("discover", help="find, enrich, score and draft new leads")
    d.add_argument("--types", default=",".join(ALL_TYPES), help="comma list: expansion,it_services,partner")
    d.add_argument("--limit", type=int, default=25, help="max new companies per run (controls API cost)")
    d.add_argument("--csv", default=None, help="also import leads from a CSV (Apollo / Sales Navigator export etc.)")
    d.add_argument("--demo", action="store_true", help="use sample data, no API keys needed")

    sub.add_parser("stats", help="show conversion by score band, lead type, source")

    e = sub.add_parser("export", help="export Approved leads to CSV and mark them Exported")
    e.add_argument("--out", default="approved_leads.csv")
    e.add_argument("--no-mark", action="store_true", help="don't mark rows as Exported")

    a = ap.parse_args()
    cfg = load_config(a.config)

    if a.cmd == "discover":
        types = [t.strip() for t in a.types.split(",") if t.strip()]
        bad = [t for t in types if t not in ALL_TYPES]
        if bad:
            ap.error(f"unknown types {bad}; choose from {ALL_TYPES}")
        run_discovery(cfg, a.sheet, types, a.limit, a.csv, a.demo)
    elif a.cmd == "stats":
        print(sheet.stats(a.sheet))
    elif a.cmd == "export":
        ready, skipped = sheet.export_approved(a.sheet, a.out, mark=not a.no_mark)
        print(f"Exported {ready} approved leads to {a.out}.")
        if skipped:
            print(f"{skipped} approved rows skipped (missing Email or Email Draft). Fill them in and run again.")


if __name__ == "__main__":
    main()
