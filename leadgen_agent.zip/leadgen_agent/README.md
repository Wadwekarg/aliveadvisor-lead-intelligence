# Aliveadvisor Lead-Gen Agent (semi-automated)

Finds companies -> enriches them -> scores them with Claude -> drafts outreach -> writes everything to
`leads.xlsx` for **you** to approve. Nothing is ever sent automatically.

## 1. Setup (5 minutes)

```bash
pip install -r requirements.txt
cp .env.example .env        # then paste your keys into .env
```

| Key | Needed? | Where to get it | Used for |
|---|---|---|---|
| `ANTHROPIC_API_KEY` | yes | console.anthropic.com | scoring + drafting |
| `SERPER_API_KEY` | yes (or use `--csv`) | serper.dev (free credits) | Google search + news |
| `HUNTER_API_KEY` | optional, recommended | hunter.io | decision-maker names + emails |

Edit `config.yaml`: set `sender_name` / `sender_title`, and review the ICP, search queries and scoring rubric.

## 2. Try it with no keys

```bash
python run.py discover --demo
```
Creates `leads.xlsx` from fictional sample companies so you can see the layout.

## 3. Daily workflow

```bash
python run.py discover --limit 25          # new leads -> leads.xlsx (skips companies already in the sheet)
python run.py discover --types expansion   # only one lead type
python run.py discover --csv export.csv    # also pull in a Sales Navigator / Apollo / Crunchbase export
```

Then in Excel:
1. Read each row's **Why It Fits** and the draft. Edit anything.
2. Set **Status** -> `Approved` / `Needs Edit` / `Rejected`.
3. `python run.py export` -> `approved_leads.csv` (rows marked `Exported`). Send manually, or import into
   Instantly / Lemlist / Smartlead / your mail merge.
4. Update **Outcome** (Sent, Replied, Meeting Booked...) as results come in.

## 4. Tuning loop (this is what earns auto-sending)

```bash
python run.py stats
```
Shows approval rate and reply rate by score band, lead type and source. Rules of thumb:
- High-score bands should reply more than low ones. If not, rewrite `scoring.rubric` in `config.yaml`.
- Lots of Rejected from one source -> remove those queries or add domains to `exclude_domains`.
- Edit `icp.description` with real examples of who replied.
- Raise `min_score_to_list` once the bottom band proves useless.

**Suggested gate before adding auto-send:** ~100 sent emails, approval rate above ~70% with few edits to drafts,
and reply rate clearly higher in the 70+ band than the 40-59 band.

## LinkedIn

LinkedIn does not allow scraping, and accounts that do it get restricted. The compliant route:
run searches in Sales Navigator (or Apollo / another vendor), export the list to CSV, and use
`--csv`. The agent then enriches, scores and drafts for them like any other lead. Column names are
matched flexibly (Company, Website, First Name, Last Name, Title, Email, LinkedIn URL, Country, Notes).

## Project layout

```
run.py              CLI (discover / stats / export)
config.yaml         ICP, queries, rubric, sender info  <- the file you tune
agent/sources.py    Google + news search (Serper), CSV import
agent/enrich.py     website reader (respects robots.txt), contact emails, Hunter
agent/llm.py        Claude scoring / drafting / company extraction
agent/sheet.py      spreadsheet read/write, stats, export
agent/pipeline.py   the orchestration
```

## Cost / limits

Roughly 2 Claude calls per kept lead plus 1 per news hit. `--limit` caps companies per run.
Start with 25.

## Compliance

- Use business emails only; keep the unsubscribe/opt-out line (`email_footer`).
- Follow CAN-SPAM, GDPR and local rules (e.g. PDPA) for the countries you target.
- Send from a separate domain, warm it up, and start with 20-30 emails/day.
- Generic addresses (info@) are lower quality; prefer rows with a named contact.

## Adding auto-send later

The `export` step is the seam: replace it with an SMTP/Gmail API or Instantly API call that sends rows
where Status = Approved and Outcome is blank, with per-day caps and a bounce/unsubscribe check.
